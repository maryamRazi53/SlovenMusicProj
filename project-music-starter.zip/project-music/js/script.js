const SEARCH_URL = 'https://itunes.apple.com/search?media=music&entity=song&limit=20&term=';
const START_TERM = 'pop';
